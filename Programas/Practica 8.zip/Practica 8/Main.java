public class Main {
    public static void main(String[] args) {
        new Parte1();
        new Parte2();
        new Parte2_1();
        new Parte2_2();
        new Parte2_3();
        new Parte2_4();
        new Parte2_5();
        new Parte2_6();
    }
}
