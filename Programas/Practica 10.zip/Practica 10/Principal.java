public class Principal {
    public static void main(String[] args) {
        new Parte1();
        new Parte4();
        new Parte5();
        new Parte6();
    }
}